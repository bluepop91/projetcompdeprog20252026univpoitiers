var searchData=
[
  ['_2enetcoreapp_2cversion_3dv10_2e0_2eassemblyattributes_2ecs_0',['.NETCoreApp,Version=v10.0.AssemblyAttributes.cs',['../_interface_tetris_2obj_2_debug_2net10_80_2_8_n_e_t_core_app_00_version_0av10_80_8_assembly_attributes_8cs.html',1,'(Espace de nommage global)'],['../_noyau_tetris_2obj_2_debug_2net10_80_2_8_n_e_t_core_app_00_version_0av10_80_8_assembly_attributes_8cs.html',1,'(Espace de nommage global)'],['../_test_tetris_2obj_2_debug_2net10_80_2_8_n_e_t_core_app_00_version_0av10_80_8_assembly_attributes_8cs.html',1,'(Espace de nommage global)']]]
];
